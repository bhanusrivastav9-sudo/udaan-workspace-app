import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:url_launcher/url_launcher.dart';

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  final GlobalKey webViewKey = GlobalKey();
  InAppWebViewController? webViewController;
  PullToRefreshController? pullToRefreshController;
  
  String url = "https://udaan.foundation/udaan-workspace-app.php";
  double progress = 0;
  bool isLoading = true;
  bool hasError = false;
  bool isOffline = false;

  final InAppWebViewSettings settings = InAppWebViewSettings(
    // Performance optimizations
    useShouldOverrideUrlLoading: true,
    mediaPlaybackRequiresUserGesture: false,
    allowsInlineMediaPlayback: true,
    iframeAllow: "camera; microphone; geolocation",
    iframeAllowFullscreen: true,
    
    // Native feel settings
    useHybridComposition: true,
    disableHorizontalScroll: false,
    disableVerticalScroll: false,
    supportZoom: false,
    
    // Cache settings for better performance
    cacheEnabled: true,
    clearCache: false,
    
    // JavaScript settings
    javaScriptEnabled: true,
    javaScriptCanOpenWindowsAutomatically: true,
    
    // Appearance
    transparentBackground: true,
    
    // Android specific
    useWideViewPort: true,
    loadWithOverviewMode: true,
    builtInZoomControls: false,
    displayZoomControls: false,
    safeBrowsingEnabled: true,
    mixedContentMode: MixedContentMode.MIXED_CONTENT_ALWAYS_ALLOW,
    
    // iOS specific
    allowsLinkPreview: true,
    ignoresViewportScaleLimits: false,
    suppressesIncrementalRendering: false,
  );

  @override
  void initState() {
    super.initState();
    
    pullToRefreshController = PullToRefreshController(
      settings: PullToRefreshSettings(
        color: Colors.blue,
      ),
      onRefresh: () async {
        await webViewController?.reload();
      },
    );
    
    _checkConnectivity();
  }

  Future<void> _checkConnectivity() async {
    final connectivityResult = await Connectivity().checkConnectivity();
    setState(() {
      isOffline = connectivityResult == ConnectivityResult.none;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isOffline) {
      return _buildNoInternetScreen();
    }

    return WillPopScope(
      onWillPop: _onWillPop,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              InAppWebView(
                key: webViewKey,
                initialUrlRequest: URLRequest(url: WebUri(url)),
                initialSettings: settings,
                pullToRefreshController: pullToRefreshController,
                onWebViewCreated: (controller) {
                  webViewController = controller;
                  
                  // Add JavaScript handlers for better native integration
                  controller.addJavaScriptHandler(
                    handlerName: 'flutterChannel',
                    callback: (args) {
                      // Handle messages from website JavaScript
                      return {'status': 'success'};
                    },
                  );
                },
                onLoadStart: (controller, url) {
                  setState(() {
                    isLoading = true;
                    hasError = false;
                  });
                },
                onLoadStop: (controller, url) async {
                  pullToRefreshController?.endRefreshing();
                  setState(() {
                    isLoading = false;
                  });
                  
                  // Inject CSS for native feel (hide scrollbars, adjust padding, etc.)
                  await controller.evaluateJavascript(source: """
                    (function() {
                      // Hide scrollbars for cleaner native feel
                      var style = document.createElement('style');
                      style.innerHTML = `
                        ::-webkit-scrollbar { width: 0px; height: 0px; }
                        * { -webkit-tap-highlight-color: transparent; }
                        body { -webkit-touch-callout: none; }
                      `;
                      document.head.appendChild(style);
                      
                      // Prevent long-press context menu on images
                      document.addEventListener('contextmenu', function(e) {
                        e.preventDefault();
                      }, false);
                    })();
                  """);
                },
                onReceivedError: (controller, request, error) {
                  pullToRefreshController?.endRefreshing();
                  setState(() {
                    hasError = true;
                    isLoading = false;
                  });
                },
                onProgressChanged: (controller, progress) {
                  if (progress == 100) {
                    pullToRefreshController?.endRefreshing();
                  }
                  setState(() {
                    this.progress = progress / 100;
                  });
                },
                shouldOverrideUrlLoading: (controller, navigationAction) async {
                  var uri = navigationAction.request.url!;
                  
                  // Handle external links (PDF, external websites, etc.)
                  if (![
                    "http",
                    "https",
                    "file",
                    "chrome",
                    "data",
                    "javascript",
                    "about"
                  ].contains(uri.scheme)) {
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                      return NavigationActionPolicy.CANCEL;
                    }
                  }
                  
                  return NavigationActionPolicy.ALLOW;
                },
                onDownloadStartRequest: (controller, url) async {
                  // Handle downloads
                  if (await canLaunchUrl(url.url)) {
                    await launchUrl(url.url, mode: LaunchMode.externalApplication);
                  }
                },
                onConsoleMessage: (controller, consoleMessage) {
                  // Debug console messages from website
                  print("Console: ${consoleMessage.message}");
                },
              ),
              
              // Loading indicator
              if (isLoading)
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey.shade200,
                  valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
                ),
              
              // Error screen
              if (hasError && !isLoading)
                _buildErrorScreen(),
            ],
          ),
        ),
      ),
    );
  }

  Future<bool> _onWillPop() async {
    if (webViewController != null) {
      if (await webViewController!.canGoBack()) {
        webViewController!.goBack();
        return false;
      }
    }
    return true;
  }

  Widget _buildErrorScreen() {
    return Container(
      color: Colors.white,
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 20),
            Text(
              'Failed to load page',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Please check your connection and try again',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  hasError = false;
                });
                webViewController?.reload();
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
              child: const Text(
                'Retry',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoInternetScreen() {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.wifi_off,
              size: 80,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 20),
            Text(
              'No Internet Connection',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                color: Colors.grey.shade700,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              'Please check your connection',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey.shade600,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () async {
                await _checkConnectivity();
                if (!isOffline) {
                  setState(() {});
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 15),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
              ),
              child: const Text(
                'Retry',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
