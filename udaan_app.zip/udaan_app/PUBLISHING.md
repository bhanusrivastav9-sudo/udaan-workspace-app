# 📱 App Store Publishing Checklist

Complete guide to publish your app on Google Play Store and Apple App Store.

---

## 🎯 Pre-Publishing Checklist

### ✅ App Basics
- [ ] App name finalized
- [ ] App icon created (1024x1024 PNG)
- [ ] Splash screen customized
- [ ] Website URL is correct and working
- [ ] Tested on multiple devices
- [ ] All features working correctly
- [ ] No crashes or major bugs

### ✅ Legal Requirements
- [ ] Privacy Policy created
- [ ] Terms of Service created
- [ ] Contact email set up
- [ ] Company/Developer name decided
- [ ] Content rating understood

### ✅ Marketing Materials
- [ ] App screenshots (required: 2-8 screenshots)
- [ ] Feature graphic (1024x500 for Android)
- [ ] App description written (short & long)
- [ ] What's new section written
- [ ] Keywords/tags prepared
- [ ] Promotional video (optional but recommended)

---

## 🤖 ANDROID - Google Play Store

### Step 1: Prepare Your App

#### 1.1 Update App Details

**File:** `android/app/build.gradle`

```gradle
defaultConfig {
    applicationId "com.udaan.workspace"  // Change this!
    minSdkVersion 21
    targetSdkVersion 34
    versionCode 1        // Increment for each update
    versionName "1.0.0"  // User-visible version
}
```

#### 1.2 Create App Icon

Run:
```bash
flutter pub run flutter_launcher_icons
```

#### 1.3 Create Keystore (App Signing)

```bash
keytool -genkey -v -keystore ~/upload-keystore.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload

# Save this info securely:
# - Keystore password
# - Key password
# - Alias name
# - Keystore file location
```

#### 1.4 Configure Signing

Create `android/key.properties`:
```properties
storePassword=your_keystore_password
keyPassword=your_key_password
keyAlias=upload
storeFile=/Users/yourname/upload-keystore.jks
```

Update `android/app/build.gradle`:
```gradle
// Add before android block
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    // ... existing code
    
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
            minifyEnabled true
            shrinkResources true
        }
    }
}
```

### Step 2: Build Release APK

```bash
# Clean build
flutter clean
flutter pub get

# Build App Bundle (recommended for Play Store)
flutter build appbundle --release

# Or build APK
flutter build apk --release
```

**Output locations:**
- App Bundle: `build/app/outputs/bundle/release/app-release.aab`
- APK: `build/app/outputs/flutter-apk/app-release.apk`

### Step 3: Create Play Console Account

1. Go to: https://play.google.com/console
2. Pay one-time $25 registration fee
3. Complete account setup
4. Verify identity (if required)

### Step 4: Create New App

1. Click **"Create app"**
2. Fill in:
   - App name
   - Default language
   - App/Game selection
   - Free/Paid

### Step 5: Store Listing

#### App Details
- **Short description** (80 chars max)
  ```
  Udaan Workspace - Your productivity hub on the go
  ```

- **Full description** (4000 chars max)
  ```
  Udaan Workspace brings the full power of your workspace to your mobile device.
  
  Features:
  • Fast and responsive interface
  • Secure login and data protection
  • Full feature parity with web version
  • Optimized for mobile use
  • Regular updates and improvements
  
  About Udaan Foundation:
  [Your foundation description]
  
  Contact us: [email]
  Visit: [website]
  ```

#### Graphics
Upload:
- [ ] App icon (512x512 PNG)
- [ ] Feature graphic (1024x500 PNG/JPEG)
- [ ] Screenshots (2-8 images)
  - Phone: 16:9 or 9:16 ratio
  - Recommended: 1080x1920 or 1920x1080

#### Categorization
- [ ] Choose app category
- [ ] Add tags
- [ ] Select content rating

#### Contact Details
- [ ] Email address
- [ ] Website (optional)
- [ ] Phone number (optional)

#### Privacy Policy
- [ ] URL to your privacy policy (required)

### Step 6: Content Rating

1. Start questionnaire
2. Answer questions honestly
3. Get rating assigned
4. Save

### Step 7: App Content

Fill out:
- [ ] Target audience
- [ ] News apps (if applicable)
- [ ] COVID-19 contact tracing (if applicable)
- [ ] Data safety (very important!)
  - What data you collect
  - How it's used
  - Whether it's shared

### Step 8: Pricing & Distribution

- [ ] Select countries
- [ ] Choose free or paid
- [ ] Agree to terms

### Step 9: Upload App Bundle

1. **Production** → **Create new release**
2. Upload your `.aab` file
3. Add release notes:
   ```
   Initial release of Udaan Workspace app
   
   Features:
   - Full workspace access on mobile
   - Secure and fast
   - Native mobile experience
   ```
4. **Save** → **Review release**
5. **Start rollout to Production**

### Step 10: Submit for Review

- Review all information
- Click **"Send for review"**
- Wait 1-3 days for approval

---

## 🍎 iOS - Apple App Store

### Step 1: Prepare Your App

#### 1.1 Update Bundle Identifier

Open in Xcode:
```bash
open ios/Runner.xcworkspace
```

1. Select **Runner** in project navigator
2. Select **Runner** under TARGETS
3. Go to **Signing & Capabilities**
4. Change **Bundle Identifier**: `com.udaan.workspace`

#### 1.2 Configure App Icon

Add your icon in Xcode:
1. Click **Assets.xcassets** in project navigator
2. Click **AppIcon**
3. Drag your icon files to each size slot

Or use:
```bash
flutter pub run flutter_launcher_icons
```

#### 1.3 Update Version & Build

In Xcode:
- **Version**: 1.0.0 (user-facing)
- **Build**: 1 (increment for each upload)

Or in `ios/Runner/Info.plist`:
```xml
<key>CFBundleShortVersionString</key>
<string>1.0.0</string>
<key>CFBundleVersion</key>
<string>1</string>
```

### Step 2: Build for iOS

```bash
# Clean build
flutter clean
flutter pub get

# Build iOS
flutter build ios --release
```

### Step 3: Archive in Xcode

1. Open: `open ios/Runner.xcworkspace`
2. Select **Generic iOS Device** or **Any iOS Device (arm64)** as destination
3. **Product** → **Clean Build Folder**
4. **Product** → **Archive**
5. Wait for archive to complete

### Step 4: Validate Archive

1. **Window** → **Organizer**
2. Select your archive
3. Click **Validate App**
4. Follow wizard:
   - App Store Connect
   - Select your team
   - Automatically manage signing
   - Wait for validation

### Step 5: Upload to App Store

1. In Organizer, click **Distribute App**
2. Choose **App Store Connect**
3. Click **Upload**
4. Follow wizard
5. Wait for upload to complete (can take 15-60 minutes)

### Step 6: Create App Store Connect Account

1. Go to: https://developer.apple.com
2. Enroll in Apple Developer Program ($99/year)
3. Complete payment and verification
4. Go to: https://appstoreconnect.apple.com

### Step 7: Create New App

1. Click **"+"** → **New App**
2. Fill in:
   - Platform: iOS
   - Name: Udaan Workspace
   - Primary Language
   - Bundle ID: (select your bundle ID)
   - SKU: unique identifier (e.g., UDAAN-WORKSPACE-001)
   - User Access: Full Access

### Step 8: App Information

#### General Information
- [ ] App name
- [ ] Subtitle (30 chars)
- [ ] Category (primary & secondary)
- [ ] Content rights

#### Version Information
- [ ] Screenshots (required for all sizes):
  - 6.5" display (iPhone 14 Pro Max): 1290 x 2796
  - 5.5" display (iPhone 8 Plus): 1242 x 2208
  - 12.9" iPad Pro: 2048 x 2732
  - (or use app screenshot feature)

- [ ] Promotional text (170 chars - optional)
- [ ] Description (4000 chars max)
  ```
  Udaan Workspace brings your full workspace experience to iOS.
  
  FEATURES:
  • Fast, native performance
  • Secure authentication
  • Full feature access
  • Optimized for iPhone and iPad
  • Regular updates
  
  ABOUT UDAAN FOUNDATION:
  [Your description]
  
  Support: [email]
  Website: [url]
  ```

- [ ] Keywords (100 chars - comma-separated)
  ```
  workspace, productivity, udaan, foundation, collaboration
  ```

- [ ] Support URL
- [ ] Marketing URL (optional)

### Step 9: Pricing & Availability

- [ ] Select price tier (Free)
- [ ] Choose countries
- [ ] Pre-orders (optional)

### Step 10: App Privacy

**Very Important!** Fill out:
1. Click **Get Started**
2. Answer questions about:
   - Data collection
   - Data usage
   - Data linking
   - Tracking
3. Publish privacy information

### Step 11: Age Rating

Answer questionnaire:
- Violence
- Profanity
- Sexual content
- Gambling
- Etc.

### Step 12: Build Selection

1. Go to **App Store** → **iOS App**
2. Under **Build**, click **"+"**
3. Select the build you uploaded
4. Wait for it to process (can take hours)

### Step 13: Review Information

Fill out:
- [ ] Contact information
- [ ] Notes for reviewer (explain login if needed)
- [ ] Demo account (if app requires login)

### Step 14: Submit for Review

1. Click **Add for Review**
2. Click **Submit to App Review**
3. Wait 1-3 days for review

---

## 📋 Post-Submission Checklist

### During Review
- [ ] Monitor email for updates
- [ ] Be ready to respond to reviewer questions
- [ ] Have demo account ready (if needed)

### After Approval
- [ ] Test download from store
- [ ] Monitor crash reports
- [ ] Respond to user reviews
- [ ] Plan first update

### Updates
When updating:
1. Increment version numbers
2. Build new release
3. Upload to stores
4. Add what's new notes
5. Submit for review

---

## 📸 Screenshot Templates

### Android Screenshot Sizes
- Phone: 1080 x 1920 (portrait)
- Tablet: 1920 x 1080 (landscape)

### iOS Screenshot Sizes
- 6.5" (iPhone 14 Pro Max): 1290 x 2796
- 5.5" (iPhone 8 Plus): 1242 x 2208
- 12.9" iPad Pro: 2048 x 2732

**Pro Tip:** Use Figma or Canva templates for professional screenshots.

---

## ⏱️ Timeline Expectations

### Google Play Store
- Account setup: Instant (after payment)
- First review: 1-3 days (can be up to 7 days)
- Updates: Usually faster, 1-2 days

### Apple App Store
- Account setup: 1-2 days
- First review: 1-3 days (can be up to 7 days)
- Updates: 1-2 days

---

## 💰 Costs

### One-Time
- Google Play Developer: $25 (lifetime)
- Apple Developer: $99/year

### Ongoing
- Apple Developer: $99/year renewal
- Optional: Marketing, analytics tools

---

## 🚨 Common Rejection Reasons

### Both Stores
- ❌ Misleading screenshots
- ❌ Broken functionality
- ❌ Missing privacy policy
- ❌ Inappropriate content
- ❌ Copyright issues
- ❌ Login issues (provide test account!)

### Android Specific
- ❌ Incorrect content rating
- ❌ Missing data safety info
- ❌ Incomplete store listing

### iOS Specific
- ❌ Missing required screenshots
- ❌ App crashes on launch
- ❌ Incomplete metadata
- ❌ Guideline violations

---

## ✅ Final Pre-Submission Test

Before submitting:
- [ ] Install release build on real device
- [ ] Test all features
- [ ] Verify splash screen
- [ ] Test on slow internet
- [ ] Test file uploads
- [ ] Check for crashes
- [ ] Test back navigation
- [ ] Verify all buttons work
- [ ] Check landscape/portrait
- [ ] Test on different screen sizes

---

## 📞 Support Resources

- **Google Play Console Help**: https://support.google.com/googleplay/android-developer
- **App Store Connect Help**: https://developer.apple.com/help/app-store-connect
- **Flutter Publishing Guide**: https://flutter.dev/docs/deployment

Good luck with your app launch! 🚀
