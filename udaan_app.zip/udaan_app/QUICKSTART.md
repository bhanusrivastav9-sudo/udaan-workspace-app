# 🚀 Quick Start Guide

## For Complete Beginners

### Step 1: Install Flutter (One-time setup)

**Windows:**
1. Download Flutter: https://docs.flutter.dev/get-started/install/windows
2. Extract to `C:\flutter`
3. Add to PATH: `C:\flutter\bin`
4. Install Android Studio: https://developer.android.com/studio

**Mac:**
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Flutter
brew install --cask flutter

# Install Xcode from App Store (for iOS)
```

**Linux:**
```bash
# Download and extract Flutter
cd ~
wget https://storage.googleapis.com/flutter_infra_release/releases/stable/linux/flutter_linux_3.16.0-stable.tar.xz
tar xf flutter_linux_3.16.0-stable.tar.xz

# Add to PATH
echo 'export PATH="$PATH:$HOME/flutter/bin"' >> ~/.bashrc
source ~/.bashrc
```

### Step 2: Verify Installation

```bash
flutter doctor
```

Follow instructions to fix any issues (install Android Studio, accept licenses, etc.)

### Step 3: Run Your App

**In the udaan_app folder:**

```bash
# Get dependencies
flutter pub get

# Run on connected device or emulator
flutter run
```

That's it! The app should launch.

## Build Release Version

### Android APK (for distribution)

```bash
flutter build apk --release
```

Find your APK at: `build/app/outputs/flutter-apk/app-release.apk`

You can now:
- Install this APK directly on Android devices
- Upload to Google Play Store
- Share via email/website

### iOS (Mac only)

```bash
flutter build ios --release
open ios/Runner.xcworkspace
```

In Xcode: Product → Archive → Distribute App

## Need Help?

**Common Commands:**
- `flutter clean` - Clean build files
- `flutter pub get` - Install dependencies
- `flutter devices` - List connected devices
- `flutter emulators` - List emulators
- `flutter run` - Run app in debug mode
- `flutter build apk` - Build Android APK

**Can't run?**
1. Run `flutter doctor` and fix all issues
2. Make sure a device is connected or emulator is running
3. Run `flutter clean` then `flutter pub get`
4. Try `flutter run -v` for detailed errors

**Still stuck?**
- Check the full README.md
- Visit: https://flutter.dev/docs/get-started/install
- Google the error message
