# 🔧 Troubleshooting Guide

## Common Issues and Solutions

### 1. App Won't Start / Crashes Immediately

**Symptoms:**
- App closes immediately after opening
- Blank white screen
- "App has stopped" error

**Solutions:**

**A. Clear Flutter cache:**
```bash
flutter clean
flutter pub get
flutter run
```

**B. Rebuild the app:**
```bash
cd android
./gradlew clean
cd ..
flutter run
```

**C. Check permissions in AndroidManifest.xml:**
Ensure `INTERNET` permission is present.

**D. For iOS:**
```bash
cd ios
pod deintegrate
pod install
cd ..
flutter run
```

---

### 2. Website Not Loading / Blank WebView

**Symptoms:**
- App opens but shows blank screen
- "Failed to load page" error
- Endless loading

**Solutions:**

**A. Check internet connection:**
- Ensure device has internet
- Try opening website in browser

**B. Verify URL is correct:**
In `lib/screens/webview_screen.dart`, check:
```dart
String url = "https://udaan.foundation/udaan-workspace-app.php";
```

**C. Check for HTTP vs HTTPS:**
If your site uses HTTP (not HTTPS), add to `AndroidManifest.xml`:
```xml
android:usesCleartextTraffic="true"
```

**D. Disable SSL pinning (temporary testing only):**
In `lib/screens/webview_screen.dart`, add to settings:
```dart
settings: InAppWebViewSettings(
  // ... other settings
  allowUniversalAccessFromFileURLs: true,
),
```

---

### 3. Camera/File Upload Not Working

**Symptoms:**
- Clicking file input does nothing
- Camera doesn't open
- "Permission denied" errors

**Solutions:**

**A. Check AndroidManifest.xml has permissions:**
```xml
<uses-permission android:name="android.permission.CAMERA"/>
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
```

**B. For Android 13+, add to AndroidManifest.xml:**
```xml
<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
```

**C. Check iOS Info.plist:**
```xml
<key>NSCameraUsageDescription</key>
<string>This app needs camera access</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>This app needs photo access</string>
```

**D. Request permissions at runtime:**
Add to `pubspec.yaml`:
```yaml
dependencies:
  permission_handler: ^11.1.0
```

---

### 4. Back Button Not Working

**Symptoms:**
- Back button exits app instead of going back
- Can't navigate back in WebView

**Solutions:**

**A. Check WillPopScope is in webview_screen.dart:**
Should be around line 127:
```dart
return WillPopScope(
  onWillPop: _onWillPop,
  // ...
);
```

**B. If removed, add it back:**
```dart
Future<bool> _onWillPop() async {
  if (webViewController != null) {
    if (await webViewController!.canGoBack()) {
      webViewController!.goBack();
      return false;
    }
  }
  return true;
}
```

---

### 5. App Runs in Debug but Crashes in Release

**Symptoms:**
- Works with `flutter run`
- Crashes with `flutter build apk --release`

**Solutions:**

**A. Add ProGuard rules:**
Create `android/app/proguard-rules.pro`:
```
-keep class io.flutter.** { *; }
-keep class com.pichillilorenzo.** { *; }
```

Add to `android/app/build.gradle`:
```gradle
buildTypes {
    release {
        minifyEnabled true
        proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
    }
}
```

**B. Disable minification temporarily:**
In `android/app/build.gradle`:
```gradle
buildTypes {
    release {
        minifyEnabled false
        shrinkResources false
    }
}
```

---

### 6. Gradle Build Failed

**Symptoms:**
- "Could not resolve dependencies"
- "Gradle build failed"
- "Execution failed for task"

**Solutions:**

**A. Update Gradle version:**
In `android/gradle/wrapper/gradle-wrapper.properties`:
```properties
distributionUrl=https\://services.gradle.org/distributions/gradle-8.0-all.zip
```

**B. Clear Gradle cache:**
```bash
cd android
./gradlew clean
./gradlew --stop
cd ..
flutter clean
flutter pub get
```

**C. Delete build folders:**
```bash
rm -rf android/build
rm -rf build
flutter build apk
```

---

### 7. iOS Build Failed / Pod Install Errors

**Symptoms:**
- "pod install failed"
- "CocoaPods not installed"
- Xcode build errors

**Solutions:**

**A. Update CocoaPods:**
```bash
sudo gem install cocoapods
pod repo update
```

**B. Clean and reinstall pods:**
```bash
cd ios
rm -rf Pods
rm Podfile.lock
pod install --repo-update
cd ..
flutter clean
flutter build ios
```

**C. Update iOS deployment target:**
In `ios/Podfile`, uncomment and set:
```ruby
platform :ios, '12.0'
```

---

### 8. Splash Screen Not Showing

**Symptoms:**
- App starts directly on website
- Splash screen skipped

**Solutions:**

**A. Check main.dart route:**
Should navigate to SplashScreen:
```dart
home: const SplashScreen(),
```

**B. Check timer duration:**
In `lib/screens/splash_screen.dart`:
```dart
Timer(const Duration(seconds: 3), () {
  // Navigation code
});
```

**C. Clear app data and reinstall:**
```bash
flutter clean
flutter run
```

---

### 9. App Too Slow / Laggy

**Symptoms:**
- Slow scrolling
- Delayed interactions
- Choppy animations

**Solutions:**

**A. Enable hardware acceleration:**
In `AndroidManifest.xml`:
```xml
<application android:hardwareAccelerated="true">
```

**B. Optimize WebView settings:**
In `lib/screens/webview_screen.dart`:
```dart
settings: InAppWebViewSettings(
  useHybridComposition: true,
  cacheEnabled: true,
),
```

**C. Optimize your website:**
- Minimize JavaScript
- Optimize images
- Use lazy loading
- Enable browser caching

**D. Build release version:**
Debug builds are slower. Test with:
```bash
flutter build apk --release
```

---

### 10. Pull-to-Refresh Not Working

**Symptoms:**
- Can't pull down to refresh
- No refresh animation

**Solutions:**

**A. Check controller is assigned:**
In `lib/screens/webview_screen.dart`:
```dart
pullToRefreshController: pullToRefreshController,
```

**B. Check controller initialization:**
Should be in `initState()`:
```dart
pullToRefreshController = PullToRefreshController(
  onRefresh: () async {
    await webViewController?.reload();
  },
);
```

---

### 11. External Links Not Opening

**Symptoms:**
- PDFs don't open
- External links stuck
- "Unable to open" errors

**Solutions:**

**A. Check URL launcher:**
In `pubspec.yaml`:
```yaml
dependencies:
  url_launcher: ^6.2.2
```

**B. Verify shouldOverrideUrlLoading:**
Should be in webview_screen.dart around line 150.

**C. Add intent filters (Android):**
In `AndroidManifest.xml`:
```xml
<queries>
    <intent>
        <action android:name="android.intent.action.VIEW" />
        <data android:scheme="https" />
    </intent>
</queries>
```

---

### 12. Can't Install APK on Android

**Symptoms:**
- "App not installed"
- "Parsing error"
- Installation blocked

**Solutions:**

**A. Enable "Install from Unknown Sources":**
Settings → Security → Unknown Sources → Enable

**B. Build APK correctly:**
```bash
flutter build apk --release
```

**C. Check minimum SDK version:**
In `android/app/build.gradle`:
```gradle
minSdkVersion 21  // Should work for most devices
```

**D. Try App Bundle instead:**
```bash
flutter build appbundle --release
```

---

## 🔍 Debug Mode Tips

### Check Logs

**Android:**
```bash
flutter logs
# or
adb logcat
```

**iOS:**
```bash
flutter logs
```

### Verbose Build

```bash
flutter run -v
flutter build apk -v
```

### Check Device Info

```bash
flutter devices
flutter doctor -v
```

---

## 📱 Testing Checklist

Before releasing, test:

- [ ] App installs successfully
- [ ] Splash screen shows correctly
- [ ] Website loads completely
- [ ] Pull-to-refresh works
- [ ] Back button navigation works
- [ ] Camera/file upload works
- [ ] External links open
- [ ] Offline mode shows error
- [ ] App doesn't crash on rotation
- [ ] No console errors
- [ ] Performance is smooth

---

## 🆘 Still Having Issues?

1. **Search the error message** on Google with "Flutter" prefix
2. **Check Flutter GitHub issues**: https://github.com/flutter/flutter/issues
3. **Check WebView plugin issues**: https://github.com/pichillilorenzo/flutter_inappwebview/issues
4. **Run flutter doctor** and fix all issues
5. **Try on a different device/emulator**
6. **Create a minimal test** - simplify your code to find the issue

## 📚 Helpful Resources

- Flutter Documentation: https://flutter.dev/docs
- Flutter Troubleshooting: https://flutter.dev/docs/testing/debugging
- Stack Overflow: https://stackoverflow.com/questions/tagged/flutter
- Flutter Community: https://flutter.dev/community

## 🔄 Nuclear Option (Last Resort)

If nothing works, start fresh:

```bash
# Backup your customizations first!
flutter clean
cd android
./gradlew clean
cd ../ios
pod deintegrate
pod install
cd ..
flutter pub get
flutter run
```

If still failing, recreate the project and copy your customizations over.
