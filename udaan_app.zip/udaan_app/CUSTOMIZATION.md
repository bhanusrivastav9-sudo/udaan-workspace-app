# 🎨 Customization Guide for Non-Developers

This guide helps you customize the app WITHOUT coding knowledge!

## 1️⃣ Change App Colors

### Splash Screen Colors

**File:** `lib/screens/splash_screen.dart`

**Find line 76-82:**
```dart
colors: [
  Colors.blue.shade50,  // ← Top background color
  Colors.white,         // ← Bottom background color
],
```

**Replace with your colors:**
```dart
colors: [
  Color(0xFFE3F2FD),  // Light blue (use hex codes)
  Color(0xFFFFFFFF),  // White
],
```

**Popular color hex codes:**
- Red: `0xFFFF0000`
- Blue: `0xFF0000FF`
- Green: `0xFF00FF00`
- Orange: `0xFFFFA500`
- Purple: `0xFF800080`
- Pink: `0xFFFFC0CB`

### App Theme Colors

**File:** `lib/main.dart`

**Find line 33:**
```dart
primarySwatch: Colors.blue,  // ← Main app color
```

**Replace with:**
```dart
primarySwatch: Colors.green,  // or red, purple, orange, etc.
```

## 2️⃣ Change Text & Branding

### App Name in Splash Screen

**File:** `lib/screens/splash_screen.dart`

**Find line 101:**
```dart
'Udaan Workspace',  // ← Your app name
```

### "from Company Name" Text

**Find line 115-124:**
```dart
Text(
  'from',
  // ...
),
Text(
  'Udaan Foundation',  // ← Your company name
  // ...
),
```

## 3️⃣ Change Splash Screen Duration

**File:** `lib/screens/splash_screen.dart`

**Find line 38:**
```dart
Timer(const Duration(seconds: 3), () {
```

Change `3` to any number:
- `2` = 2 seconds (faster)
- `5` = 5 seconds (slower)

## 4️⃣ Change Your Website URL

**File:** `lib/screens/webview_screen.dart`

**Find line 29:**
```dart
String url = "https://udaan.foundation/udaan-workspace-app.php";
```

**Replace with your URL:**
```dart
String url = "https://yourwebsite.com";
```

## 5️⃣ Change App Icon

### Option 1: Manual (All sizes needed)

Replace these files with your logo:

**Android:**
- `android/app/src/main/res/mipmap-mdpi/ic_launcher.png` (48x48 px)
- `android/app/src/main/res/mipmap-hdpi/ic_launcher.png` (72x72 px)
- `android/app/src/main/res/mipmap-xhdpi/ic_launcher.png` (96x96 px)
- `android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png` (144x144 px)
- `android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png` (192x192 px)

**iOS:**
- Use Xcode to replace icon in `ios/Runner/Assets.xcassets/AppIcon.appiconset/`

### Option 2: Automatic (Recommended)

1. Create a 1024x1024 px PNG logo
2. Save it as `assets/icon/app_icon.png`
3. Add to `pubspec.yaml`:

```yaml
dev_dependencies:
  flutter_launcher_icons: ^0.13.1

flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/icon/app_icon.png"
```

4. Run in terminal:
```bash
flutter pub get
flutter pub run flutter_launcher_icons
```

## 6️⃣ Change Splash Screen Logo

**File:** `lib/screens/splash_screen.dart`

### Current (Icon-based):
**Find lines 85-98:**
```dart
Container(
  width: 120,
  height: 120,
  decoration: BoxDecoration(
    color: Colors.blue.shade600,
    borderRadius: BorderRadius.circular(30),
  ),
  child: const Icon(
    Icons.workspace_premium,
    size: 60,
    color: Colors.white,
  ),
),
```

### Replace with Image:
```dart
Image.asset(
  'assets/images/logo.png',
  width: 150,
  height: 150,
),
```

**Then add your logo:**
1. Create `assets/images/` folder
2. Put your `logo.png` there
3. Update `pubspec.yaml`:
```yaml
flutter:
  assets:
    - assets/images/logo.png
```

## 7️⃣ Disable Features

### Disable Pull-to-Refresh

**File:** `lib/screens/webview_screen.dart`

**Find line 66 and comment it out:**
```dart
// pullToRefreshController: pullToRefreshController,
```

### Disable Zoom

**Already disabled by default** in line 40:
```dart
supportZoom: false,
```

## 8️⃣ Change Loading Color

**File:** `lib/screens/webview_screen.dart`

**Find line 218:**
```dart
valueColor: const AlwaysStoppedAnimation<Color>(Colors.blue),
```

**Change to:**
```dart
valueColor: const AlwaysStoppedAnimation<Color>(Colors.red), // or any color
```

## 9️⃣ Modify Error Messages

**File:** `lib/screens/webview_screen.dart`

**Find lines 242-251 for error text:**
```dart
Text(
  'Failed to load page',  // ← Change this
  // ...
),
Text(
  'Please check your connection and try again',  // ← And this
  // ...
),
```

## 🔟 Change Button Text & Style

**File:** `lib/screens/webview_screen.dart`

**Find line 265 (Retry button):**
```dart
child: const Text(
  'Retry',  // ← Change button text
  // ...
),
```

**Change button color (line 258):**
```dart
backgroundColor: Colors.blue,  // ← Change to Colors.red, etc.
```

## Color Reference Guide

### How to use hex colors:
```dart
Color(0xFFRRGGBB)
// FF = alpha (always FF for solid colors)
// RR = Red (00-FF)
// GG = Green (00-FF)
// BB = Blue (00-FF)
```

### Common brand colors:
- **Facebook Blue:** `Color(0xFF1877F2)`
- **Twitter Blue:** `Color(0xFF1DA1F2)`
- **Instagram Gradient:** Use `Colors.purple` or `Colors.pink`
- **WhatsApp Green:** `Color(0xFF25D366)`
- **YouTube Red:** `Color(0xFFFF0000)`

## 💾 After Making Changes

1. Save all files
2. Run in terminal:
```bash
flutter clean
flutter pub get
flutter run
```

## 🆘 If Something Breaks

1. Undo your changes (Ctrl+Z)
2. Or restore from backup
3. Run:
```bash
flutter clean
flutter pub get
flutter run
```

## 📝 Tips

1. **Always backup before changing**
2. **Change one thing at a time**
3. **Test after each change**
4. **Keep hex color codes handy**: Use websites like https://htmlcolorcodes.com
5. **Use VS Code or Android Studio** for syntax highlighting

## Need More Help?

- Check full README.md for developer guide
- Visit Flutter documentation
- Google your specific customization question
