# Udaan Workspace App

A native-feeling Flutter mobile app for Udaan Foundation's workspace platform.

## 🚀 Features

- ✅ **Meta-style Splash Screen** - Professional "from Udaan Foundation" branding
- ✅ **Native Performance** - Optimized WebView with hardware acceleration
- ✅ **Pull to Refresh** - Intuitive gesture for reloading
- ✅ **Offline Detection** - Graceful handling of no internet connection
- ✅ **Back Navigation** - Native back button support
- ✅ **Error Handling** - User-friendly error screens with retry
- ✅ **Progress Indicator** - Visual feedback during page loads
- ✅ **Camera & File Upload** - Full support for media uploads
- ✅ **Location Services** - Geolocation support
- ✅ **External Link Handling** - Opens PDFs and external links properly
- ✅ **Portrait Lock** - Mobile-first orientation
- ✅ **No Scrollbar** - Clean, native appearance
- ✅ **Cache Support** - Faster subsequent loads

## 📋 Prerequisites

Before you begin, ensure you have:

- **Flutter SDK** (3.0.0 or higher) - [Install Flutter](https://flutter.dev/docs/get-started/install)
- **Android Studio** (for Android development)
- **Xcode** (for iOS development - Mac only)
- **Java JDK** (11 or higher)
- **Git**

## 🛠️ Installation & Setup

### 1. Clone or Download This Project

```bash
cd udaan_app
```

### 2. Install Dependencies

```bash
flutter pub get
```

### 3. Verify Flutter Installation

```bash
flutter doctor
```

Fix any issues reported by `flutter doctor` before proceeding.

## 📱 Running the App

### For Android

**Option 1: Using Android Emulator**
```bash
# List available emulators
flutter emulators

# Launch an emulator
flutter emulators --launch <emulator_id>

# Run the app
flutter run
```

**Option 2: Using Physical Device**
1. Enable USB debugging on your Android device
2. Connect device via USB
3. Run: `flutter run`

### For iOS (Mac only)

**Option 1: Using iOS Simulator**
```bash
# Launch simulator
open -a Simulator

# Run the app
flutter run
```

**Option 2: Using Physical Device**
1. Connect iPhone/iPad via USB
2. Trust the computer on device
3. Run: `flutter run`

## 📦 Building Release APK/IPA

### Android APK

```bash
# Build APK
flutter build apk --release

# Build App Bundle (for Play Store)
flutter build appbundle --release
```

APK location: `build/app/outputs/flutter-apk/app-release.apk`

### iOS IPA (Mac only)

```bash
# Build iOS
flutter build ios --release
```

Then open Xcode to archive and export the IPA:
```bash
open ios/Runner.xcworkspace
```

## 🎨 Customization Guide

### 1. Change App Icon

Replace these files with your logo:
- `android/app/src/main/res/mipmap-*/ic_launcher.png`
- `ios/Runner/Assets.xcassets/AppIcon.appiconset/`

Or use [flutter_launcher_icons](https://pub.dev/packages/flutter_launcher_icons):

```yaml
# In pubspec.yaml
dev_dependencies:
  flutter_launcher_icons: ^0.13.1

flutter_launcher_icons:
  android: true
  ios: true
  image_path: "assets/icon/app_icon.png"
```

Run: `flutter pub run flutter_launcher_icons`

### 2. Change App Name

**Android:** `android/app/src/main/AndroidManifest.xml`
```xml
<application android:label="Your App Name">
```

**iOS:** `ios/Runner/Info.plist`
```xml
<key>CFBundleDisplayName</key>
<string>Your App Name</string>
```

### 3. Change Bundle ID/Package Name

**Android:** `android/app/build.gradle`
```gradle
defaultConfig {
    applicationId "com.yourcompany.yourapp"
}
```

**iOS:** Open `ios/Runner.xcworkspace` in Xcode → Runner → General → Bundle Identifier

### 4. Customize Splash Screen

Edit: `lib/screens/splash_screen.dart`

- Change colors in `LinearGradient`
- Modify icon/logo
- Adjust animation duration
- Change "from Udaan Foundation" text

### 5. Change Website URL

Edit: `lib/screens/webview_screen.dart`
```dart
String url = "https://your-website.com";
```

### 6. Customize Colors & Theme

Edit: `lib/main.dart`
```dart
theme: ThemeData(
  primarySwatch: Colors.blue, // Change to your brand color
  // ... other theme properties
),
```

## 🔧 Advanced Configuration

### Enable/Disable Features

In `lib/screens/webview_screen.dart`:

```dart
final InAppWebViewSettings settings = InAppWebViewSettings(
  supportZoom: false,              // Disable pinch zoom
  builtInZoomControls: false,      // Hide zoom controls
  javaScriptEnabled: true,         // Enable JavaScript
  mediaPlaybackRequiresUserGesture: false, // Auto-play media
  // ... other settings
);
```

### Adjust Cache Settings

```dart
cacheEnabled: true,          // Enable caching
clearCache: false,           // Don't clear on app start
```

### Modify Splash Screen Duration

In `lib/screens/splash_screen.dart`:
```dart
Timer(const Duration(seconds: 3), () { // Change duration here
  // Navigation code
});
```

## 🔐 Signing the App for Release

### Android Signing

1. Create a keystore:
```bash
keytool -genkey -v -keystore ~/key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias key
```

2. Create `android/key.properties`:
```properties
storePassword=your_store_password
keyPassword=your_key_password
keyAlias=key
storeFile=/path/to/key.jks
```

3. Update `android/app/build.gradle`:
```gradle
def keystoreProperties = new Properties()
def keystorePropertiesFile = rootProject.file('key.properties')
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}

android {
    // ...
    signingConfigs {
        release {
            keyAlias keystoreProperties['keyAlias']
            keyPassword keystoreProperties['keyPassword']
            storeFile keystoreProperties['storeFile'] ? file(keystoreProperties['storeFile']) : null
            storePassword keystoreProperties['storePassword']
        }
    }
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

### iOS Signing

1. Open Xcode: `open ios/Runner.xcworkspace`
2. Select Runner → Signing & Capabilities
3. Choose your Team
4. Ensure "Automatically manage signing" is checked

## 🐛 Common Issues & Solutions

### Issue: WebView not loading

**Solution:** Check `AndroidManifest.xml` has:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
android:usesCleartextTraffic="true"
```

### Issue: App crashes on startup

**Solution:** Run:
```bash
flutter clean
flutter pub get
flutter run
```

### Issue: Camera/Location not working

**Solution:** Verify permissions in:
- `android/app/src/main/AndroidManifest.xml`
- `ios/Runner/Info.plist`

### Issue: iOS build fails

**Solution:** 
```bash
cd ios
pod install --repo-update
cd ..
flutter clean
flutter build ios
```

### Issue: Gradle build fails

**Solution:**
```bash
cd android
./gradlew clean
cd ..
flutter clean
flutter pub get
```

## 📱 Publishing to Stores

### Google Play Store

1. Build App Bundle: `flutter build appbundle --release`
2. Go to [Google Play Console](https://play.google.com/console)
3. Create new app
4. Upload the `.aab` file from `build/app/outputs/bundle/release/`
5. Fill in store listing details
6. Submit for review

### Apple App Store

1. Build iOS: `flutter build ios --release`
2. Open Xcode: `open ios/Runner.xcworkspace`
3. Product → Archive
4. Window → Organizer → Distribute App
5. Follow the wizard to upload to App Store Connect
6. Go to [App Store Connect](https://appstoreconnect.apple.com)
7. Fill in app details and submit for review

## 📄 Project Structure

```
udaan_app/
├── lib/
│   ├── main.dart                    # App entry point
│   └── screens/
│       ├── splash_screen.dart       # Meta-style splash screen
│       └── webview_screen.dart      # Main WebView with native features
├── android/                         # Android-specific files
├── ios/                            # iOS-specific files
├── assets/                         # Images, icons, etc.
└── pubspec.yaml                    # Dependencies
```

## 🔄 Updating the App

1. Make changes to your website
2. App automatically loads latest version (no app update needed!)
3. For native changes (splash screen, etc.):
   - Increment version in `pubspec.yaml`
   - Build and upload new version to stores

## 💡 Tips for Best Results

1. **Optimize Your Website:**
   - Make it mobile-responsive
   - Minimize page load time
   - Use Progressive Web App (PWA) features
   - Add a manifest.json

2. **Test Thoroughly:**
   - Test on multiple devices
   - Test with slow internet
   - Test offline behavior
   - Test all interactive elements

3. **Performance:**
   - Keep splash screen under 3 seconds
   - Enable caching
   - Optimize images on your website
   - Use CDN for assets

4. **User Experience:**
   - Handle deep links
   - Add push notifications (requires backend)
   - Implement app rating prompt
   - Add analytics (Firebase, etc.)

## 📞 Support

For issues or questions:
- Check Flutter documentation: https://flutter.dev/docs
- WebView plugin docs: https://pub.dev/packages/flutter_inappwebview
- Create an issue in your repository

## 📜 License

This project structure is provided as-is for Udaan Foundation.

## 🙏 Credits

Built with Flutter and love for Udaan Foundation
