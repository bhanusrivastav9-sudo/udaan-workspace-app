#!/bin/bash

# Udaan Workspace App - Quick Setup Script
# This script helps you get started quickly

echo "🚀 Udaan Workspace App - Quick Setup"
echo "===================================="
echo ""

# Check if Flutter is installed
if ! command -v flutter &> /dev/null
then
    echo "❌ Flutter is not installed!"
    echo ""
    echo "Please install Flutter first:"
    echo "Visit: https://flutter.dev/docs/get-started/install"
    echo ""
    exit 1
else
    echo "✅ Flutter is installed"
    flutter --version
    echo ""
fi

# Run flutter doctor
echo "🔍 Checking Flutter setup..."
echo ""
flutter doctor
echo ""

# Get dependencies
echo "📦 Installing dependencies..."
echo ""
flutter pub get
echo ""

# Check for connected devices
echo "📱 Checking for connected devices..."
echo ""
flutter devices
echo ""

# Offer to run the app
read -p "Would you like to run the app now? (y/n): " -n 1 -r
echo ""
if [[ $REPLY =~ ^[Yy]$ ]]
then
    echo "🚀 Starting app..."
    flutter run
else
    echo ""
    echo "✅ Setup complete!"
    echo ""
    echo "To run the app later, use: flutter run"
    echo "To build APK, use: flutter build apk --release"
    echo ""
    echo "📚 Check README.md for full documentation"
fi
